const LoadingPanel = (props: { loadingText?: string }) => {
  const { loadingText } = props;
  return (
    <div className="k-loading-mask">
      <div className="loading-image"></div>
      {loadingText && <h5 className="">{loadingText}</h5>}
      <div className="k-loading-color"></div>
    </div>
  );
};

export default LoadingPanel;
