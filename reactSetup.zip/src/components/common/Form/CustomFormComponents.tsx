import { DropDownList, MultiSelect } from "@progress/kendo-react-dropdowns";
import { Field, FieldProps, FieldWrapper } from "@progress/kendo-react-form";
import { Input, NumericTextBox, Switch, TextArea } from "@progress/kendo-react-inputs";
import { Error, FloatingLabel, Hint } from "@progress/kendo-react-labels";
import { useCallback, useState } from "react";
import DropdownWithSearch from "../DropDown/DropdownWithSearch";

interface ICustomFieldProps extends FieldProps {
  onFocus?: () => void;
  onBlur?: () => void;
  disabled?: boolean;
  label?: string;
  [other: string]: any;
}

export const RequiredInput = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, visited, ...others } = fieldRenderProps;

  return (
    <div>
      <Input {...others} />
      {visited && validationMessage && <Error>{validationMessage}</Error>}
    </div>
  );
};

export const CustomPassword = (props) => {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [passwordFieldTypeForPassword, setPasswordFieldTypeForPassword] = useState("password");

  const handleShowCurrentPassword = (pwdType: string) => {
    setPasswordFieldTypeForPassword(pwdType);
    setShowCurrentPassword(!showCurrentPassword);
  };

  return (
    <div className="k-form-field password-field">
      <Field {...props} type={passwordFieldTypeForPassword} component={Input} autoComplete="Off" />
      <span className="password-icon cursor-pointer">
        {showCurrentPassword ? (
          <img
            alt="show"
            loading="eager"
            width={20}
            onClick={() => handleShowCurrentPassword("password")}
            src="https://img.icons8.com/fluency-systems-regular/48/null/visible.png"
          />
        ) : (
          <img
            alt="hide"
            loading="eager"
            width={20}
            onClick={() => handleShowCurrentPassword("text")}
            src="https://img.icons8.com/fluency-systems-regular/48/null/invisible.png"
          />
        )}
      </span>
    </div>
  );
};

export const FormDropDownWithSearch = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, hint, ...others } = fieldRenderProps;
  const showValidationMessage = (touched && validationMessage) as boolean;
  const showHint = (!showValidationMessage && hint) as boolean;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";

  return (
    <FieldWrapper className="w-100">
      <div className={"k-form-field-wrap"}>
        <DropdownWithSearch {...others} />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const FormSwitch = (fieldRenderProps: ICustomFieldProps) => {
  const {
    // The meta props of the Field.
    validationMessage,
    visited,
    label,
    // The input props of the Field.
    value,
    onChange,
    onFocus,
    onBlur,
    disabled,
    // The custom props that you passed to the Field.
    ...others
  } = fieldRenderProps;

  const onValueChange = useCallback(() => {
    // onChange callback expects argument with 'value' property
    onChange({
      value: !value,
    });
  }, [onChange, value]);

  return (
    <div onFocus={onFocus} onBlur={onBlur}>
      <Switch
        disabled={disabled}
        onChange={onValueChange}
        checked={typeof value === "string" ? Boolean(value) : !!value}
        id={others.id && others.id > 0 ? others.id : 0}
      />
      {<span className="ps-1">{label}</span>}
      {
        // Display an error message after the "visited" or "touched" field is set to true.
        visited && validationMessage && <div className={"k-required"}>{validationMessage}</div>
      }
    </div>
  );
};

export const FormTextArea = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, valid, disabled, hint, label, ...others } = fieldRenderProps;
  const showValidationMessage: boolean = (touched && validationMessage) as boolean;
  const showHint = (!showValidationMessage && hint) as boolean;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";
  return (
    <FieldWrapper>
      <div className={"k-form-field-wrap"}>
        <FloatingLabel label={label} editorValid={fieldRenderProps.valid} editorValue={fieldRenderProps.value}>
          <TextArea
            valid={valid}
            id={id}
            disabled={disabled}
            rows={3}
            ariaDescribedBy={`${hindId} ${errorId}`}
            {...others}
          />
        </FloatingLabel>
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const FormMultiSelectDropDown = (fieldRenderProps: ICustomFieldProps) => {
  const { defaultValue, validationMessage, touched, id, hint, ...others } = fieldRenderProps;
  const showValidationMessage = touched && validationMessage;
  const showHint = !showValidationMessage && hint;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";
  return (
    <FieldWrapper className="w-100">
      <div className={"k-form-field-wrap"}>
        <MultiSelect {...others} defaultValue={defaultValue} />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const FormDropDown = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, hint, ...others } = fieldRenderProps;
  const showValidationMessage = touched && validationMessage;
  const showHint = !showValidationMessage && hint;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";
  return (
    <FieldWrapper className="w-100">
      <div className={"k-form-field-wrap"}>
        <DropDownList className="w-100" {...others} />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const FormInput = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, hint, value, ...others } = fieldRenderProps;
  const showValidationMessage = touched && validationMessage;
  const showHint = !showValidationMessage && hint;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";
  return (
    <FieldWrapper className="w-100">
      <div className={"k-form-field-wrap"}>
        <Input value={value || ""} {...others} />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const FormIntInput = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, hint } = fieldRenderProps;
  const showValidationMessage = touched && validationMessage;
  const showHint = !showValidationMessage && hint;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";
  return (
    <FieldWrapper>
      <div className={"k-form-field-wrap"}>
        <NumericTextBox {...fieldRenderProps} format={"#"} />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};

export const BooleanDropDown = (fieldRenderProps: ICustomFieldProps) => {
  const { validationMessage, touched, id, hint, ...others } = fieldRenderProps;
  const showValidationMessage = touched && validationMessage;
  const showHint = !showValidationMessage && hint;
  const hindId = showHint ? `${id}_hint` : "";
  const errorId = showValidationMessage ? `${id}_error` : "";

  return (
    <FieldWrapper>
      <div className={"k-form-field-wrap"}>
        <DropDownList
          {...others}
          onChange={(e) => {
            const value = {
              ...e,
              value: e.value === "true",
            };
            fieldRenderProps.onChange(value);
          }}
          value={fieldRenderProps.value + ""}
          data={["true", "false"]}
        />
        {showHint && <Hint id={hindId}>{hint}</Hint>}
        {showValidationMessage && <Error id={errorId}>{validationMessage}</Error>}
      </div>
    </FieldWrapper>
  );
};
