import { Button } from "@progress/kendo-react-buttons";
import { Input, InputChangeEvent } from "@progress/kendo-react-inputs";

interface ISearchInput {
  label?: string;
  width?: string;
  searchKeyword: string;
  handleSearch: () => void;
  handleSearchChange: (event: InputChangeEvent) => void;
}

const SearchInput = (props: ISearchInput) => {
  const { handleSearchChange, handleSearch, label, searchKeyword } = props;
  return (
    <div className="search-input d-flex align-items-end ">
      <Input
        value={searchKeyword}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleSearch();
          }
        }}
        inputMode="search"
        placeholder={label ?? "Search"}
        onChange={(e) => {
          handleSearchChange(e);
          if (e.value?.length === 0) {
            handleSearch();
          }
        }}
      />
      <Button type="button" themeColor="primary" icon="search" onClick={handleSearch}></Button>
    </div>
  );
};

export default SearchInput;
