const PercentageCell = ({ priceValue }: { priceValue: string }) => {
  return (
    <td>
      <strong>{priceValue && !Number.isNaN(priceValue) ? `${parseFloat(priceValue).toFixed(2)} %` : "-"}</strong>
    </td>
  );
};
export default PercentageCell;
