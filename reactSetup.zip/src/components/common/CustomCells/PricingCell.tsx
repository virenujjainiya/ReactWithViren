interface IPricingCellProps {
  priceValue: string | undefined | null;
  className?: string;
  nodata?: string;
}

const PricingCell = ({ priceValue, className = "", nodata = "$ 0.00" }: IPricingCellProps) => {
  return (
    <td className={className}>
      <strong>{priceValue && !Number.isNaN(priceValue) ? `$ ${parseFloat(priceValue).toFixed(2)}` : nodata}</strong>
    </td>
  );
};

export default PricingCell;
