import { Dialog } from "@progress/kendo-react-dialogs";
import React, { CSSProperties, useCallback, useEffect } from "react";

interface CustomDialogProps {
  className?: string;
  title?: string; // when you add title also get close icon with it in the header
  stage?: string;
  resizable?: boolean;
  onClose: () => void;
  modal?: boolean;
  width?: number;
  height?: number;
  minWidth?: number;
  minHeight?: number;
  children: React.ReactNode;
  show: boolean;
  style?: CSSProperties;
  appendTo?: Element | null | undefined;
}

const CustomDialog = (props: CustomDialogProps) => {
  const { show, onClose } = props;

  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (event.key === "Escape" && show) {
        onClose();
      }
    },
    [show, onClose],
  );

  useEffect(() => {
    if (show) {
      document.addEventListener("keydown", handleKeyDown);
    }
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [handleKeyDown, show]);

  return show ? <Dialog {...props} /> : <></>;
};

export default CustomDialog;
