import { CompositeFilterDescriptor, filterBy, FilterDescriptor } from "@progress/kendo-data-query";
import { DropDownList, DropDownListFilterChangeEvent, DropDownListProps } from "@progress/kendo-react-dropdowns";
import { useEffect, useState } from "react";

const DropdownWithSearch = ({ className, label, loading, data, onChange, value, ...props }: DropDownListProps) => {
  const [dropDownData, setDropdownData] = useState([]);

  useEffect(() => {
    if (data && data.length > 0) {
      setDropdownData(data);
    } else {
      setDropdownData([]);
    }
  }, [data]);

  const filterData = (filter: FilterDescriptor | CompositeFilterDescriptor): any[] => {
    const currentData: any[] = data && data.length > 0 ? data.slice() : [];
    return filterBy(currentData, filter);
  };

  const filterChange = (event: DropDownListFilterChangeEvent): void => {
    setDropdownData(filterData(event.filter));
  };

  return (
    <DropDownList
      className={className}
      filterable={true}
      label={label}
      loading={loading}
      value={value}
      onFilterChange={filterChange}
      data={dropDownData}
      onChange={onChange}
      {...props}
    />
  );
};

export default DropdownWithSearch;
