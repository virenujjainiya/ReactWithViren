import { Grid, GridColumnProps, GridProps } from "@progress/kendo-react-grid";
import React, { FC, memo } from "react";

interface ICustomGrid {
  children: React.ReactNode;
  gridProps: GridProps;
  columnProps?: GridColumnProps;
  className?: string;
}

const CustomGrid: FC<ICustomGrid> = (props: ICustomGrid) => {
  const { children, gridProps } = props;

  return (
    <Grid style={{ height: "calc(100vh - 165px)", overflow: "auto" }} {...gridProps}>
      {children}
    </Grid>
  );
};

export default memo(CustomGrid);
