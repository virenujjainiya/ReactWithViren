import { Popup } from "@progress/kendo-react-popup";
import { createRef, useRef } from "react";

const CustomPopup = (props) => {
  const { children, setShow, show, anchor, popupAlign, ...others } = props;
  const contentRef = createRef<HTMLDivElement>();
  const blurTimeoutRef = useRef<any>();

  const onOpen = (e) => {
    contentRef.current?.focus();
  };

  const onFocus = () => {
    // the user is still inside the content
    clearTimeout(blurTimeoutRef.current);
  };

  const onBlurTimeout = () => {
    // the user is now outside the popup
    setShow(false);
  };

  const onBlur = () => {
    clearTimeout(blurTimeoutRef.current);
    const temp = setTimeout(onBlurTimeout, 200);
    blurTimeoutRef.current = temp;
  };

  return (
    <Popup {...others} onOpen={onOpen} anchor={anchor} popupAlign={popupAlign} show={show} popupClass={"popup-content"}>
      <div ref={contentRef} tabIndex={0} onFocus={onFocus} onBlur={onBlur}>
        {children}
      </div>
    </Popup>
  );
};

export default CustomPopup;
