import { Slide } from "@progress/kendo-react-animation";
import { Notification, NotificationGroup } from "@progress/kendo-react-notification";
import { Dispatch, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@src/redux/reducers";
import { clearNotification } from "../../redux/reducers/slice/commonAction";

const ShowNotification: React.FC = () => {
  const dispatch: Dispatch<any> = useDispatch();

  const commonAction = useSelector((state: RootState) => state?.commonAction?.notification);

  const { type, message } = commonAction;

  const hideNotification = () => {
    dispatch(clearNotification());
  };

  useEffect(() => {
    if (type !== "clear") {
      let timer: NodeJS.Timeout | number = 0;
      if (timer) {
        clearTimeout(timer);
      }
      timer = setTimeout(function () {
        dispatch(clearNotification());
      }, 5000);
    }
  }, [type]);

  return (
    <NotificationGroup
      style={{
        right: 0,
        bottom: 10,
        alignItems: "flex-start",
        flexWrap: "wrap-reverse",
        zIndex: 99999,
      }}
    >
      {message && message.length > 0 && type !== "clear" && (
        <Slide direction="down">
          <Notification type={{ style: type, icon: true }} closable={true} onClose={hideNotification}>
            <span>{message}</span>
          </Notification>
        </Slide>
      )}
    </NotificationGroup>
  );
};

export default ShowNotification;
