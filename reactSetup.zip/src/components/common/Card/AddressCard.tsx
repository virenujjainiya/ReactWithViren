import { Card, CardBody, CardHeader } from "@progress/kendo-react-layout";
import { IBillingAddress } from "@src/interface/Order/OrderTypes";
import LoadingPanel from "../LoadingPanel";
import { SanitizedDiv } from "../SanitizedDiv";

interface IAddressCardProps {
  details: IBillingAddress;
  isLoading: boolean;
  title: string;
}

const AddressCard = ({ details, isLoading, title }: IAddressCardProps) => {
  return (
    <Card className="w-100 position-relative">
      <CardHeader>{title}</CardHeader>
      <CardBody>
        {isLoading && <LoadingPanel />}
        {details && (
          <>
            <div className="row mb-2">
              <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
                <div className="row">
                  <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Name</div>
                  <strong>
                    {
                      <SanitizedDiv
                        className={"col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12"}
                        htmlString={details.name}
                      />
                    }
                  </strong>
                </div>
              </div>
            </div>
            <div className="row mb-2">
              <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
                <div className="row">
                  <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Address</div>
                  <strong>
                    {
                      <SanitizedDiv
                        className={"col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12"}
                        htmlString={details.fullAddress}
                      />
                    }
                  </strong>
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                <div className="row">
                  <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Contact</div>
                  <strong>
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">{details.phone}</div>
                  </strong>
                  <strong>
                    <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">{details.email}</div>
                  </strong>
                </div>
              </div>
            </div>
          </>
        )}
        {!details && (
          <div className="row mb-2">
            <div className="col-12">-----</div>
          </div>
        )}
      </CardBody>
    </Card>
  );
};

export default AddressCard;
