import PercentageCell from "../CustomCells/PercentageCell";
import PricingCell from "../CustomCells/PricingCell";

const DetailRow = ({ value, label, isPricing = false, isPercentage = false }) => {
  return (
    <div className="col-12 col-sm-4 col-md-4 col-lg-4">
      <div className="row">
        <div className="col-12 col-md-12 col-sm-12 col-lg-12 detail-font">{label}</div>
        <div className="col-12 col-md-12 col-sm-12 col-lg-12 ">
          <strong>
            {isPricing ? (
              isPercentage ? (
                <PercentageCell priceValue={value} />
              ) : (
                <PricingCell priceValue={value} />
              )
            ) : (
              value || <span>-</span>
            )}
          </strong>
        </div>
      </div>
    </div>
  );
};
export default DetailRow;
