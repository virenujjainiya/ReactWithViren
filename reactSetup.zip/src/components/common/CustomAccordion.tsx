import { ReactNode } from "react";

interface props {
  title: string;
  subtitle: string;
  children: ReactNode;
  isOpen: boolean;
  onClick: any;
}

const CustomAccordion = (props: props) => {
  const { title, subtitle, children, isOpen, onClick } = props;

  return (
    <div className={(isOpen ? "expanded " : " ") + " v-accordion"}>
      <div className="v-accordion-item">
        <div className="v-accordion-header" onClick={onClick} dir="ltr">
          <div className="right-section">
            <span className="title">{title}</span>
          </div>
          <div className="left-section">
            <div className="subtitle">
              <span>{subtitle}</span>
            </div>
            <div className="indicator">
              <span
                className={"k-icon k-svg-icon " + (isOpen ? "k-i-arrow-chevron-up" : "k-i-arrow-chevron-down")}
              ></span>
            </div>
          </div>
        </div>
        <div className={(isOpen ? "expanded " : " ") + "v-accordion-content"}>
          <div className="content">{children}</div>
        </div>
      </div>
    </div>
  );
};

export default CustomAccordion;
