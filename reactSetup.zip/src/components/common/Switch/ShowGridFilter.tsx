import { Switch } from "@progress/kendo-react-inputs";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@src/redux/reducers";
import { handleFilter } from "@src/redux/reducers/slice/orderHistory";

const ShowGridFilter = () => {
  const dispatch = useDispatch();
  const showFilter = useSelector((state: RootState) => state.orderHistoryAction.showFilter);

  useEffect(() => {
    return () => {
      dispatch(handleFilter({ showFilter: false }));
    };
  }, []);

  const onFilterChange = () => {
    dispatch(handleFilter({ showFilter: !showFilter }));
  };

  return (
    <div className="align-items-center d-flex gap-1 justify-content-end my-2">
      <label className="h6 mb-0">Column Filter</label>
      <Switch checked={showFilter} onChange={onFilterChange} />
    </div>
  );
};

export default ShowGridFilter;
