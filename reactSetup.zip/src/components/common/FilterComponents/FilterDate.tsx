import { DateRangePicker, DateRangePickerProps } from "@progress/kendo-react-dateinputs";
import { DropDownList, DropDownListChangeEvent } from "@progress/kendo-react-dropdowns";
import { useCallback, useEffect, useState } from "react";
import { filterPeriodData } from "@src/components/pages/Order History/Constant";
import { formatDateFrom_ISO_to_YYYY_MM_DD } from "@src/helpers/utils";
import { FilterTag } from "@src/redux/reducers/slice/orderHistory";

interface props {
  filterName: string;
  filterLabel: string;
  value: { id: string; text: string } | null;
  onFilterChange: (filter: FilterTag) => void;
}

const FilterDate = (props: props) => {
  const [isCustom, setIsCustom] = useState(false);

  const [dateRange, setDateRange] = useState({ start: new Date(), end: new Date() });
  const [periodData, setPeriodData] = useState<{ id: string; text: string } | null>(null);

  useEffect(() => {
    setPeriodData(props.value);
  }, [props.value]);
  const handleSearchDateChange = (e: DateRangePickerProps) => {
    setDateRange(e.value);
    setFilterInRedux(periodData, e.value);
  };

  const handlePeriodChange = useCallback((e: DropDownListChangeEvent) => {
    const value: { id: string; text: string } = e.value;
    if (value.id === "Custom") {
      setIsCustom(true);
    } else {
      setIsCustom(false);
    }
    setPeriodData(value);
    setFilterInRedux(value);
  }, []);

  const setFilterInRedux = (periodData, dateRange?) => {
    let filter: FilterTag;

    let customFilterDate: { startDate: string; endDate: string };
    if (isCustom && dateRange) {
      customFilterDate = {
        startDate: formatDateFrom_ISO_to_YYYY_MM_DD(dateRange.start).toString(),
        endDate: formatDateFrom_ISO_to_YYYY_MM_DD(dateRange.end).toString(),
      };

      filter = {
        name: props.filterName,
        tagValue: `${customFilterDate.startDate} - ${customFilterDate.endDate}`,
        value: dateRange,
      };
    } else if (periodData && periodData.id) {
      filter = { name: props.filterName, tagValue: periodData.id, value: periodData };
    }

    props.onFilterChange(filter);
  };

  return (
    <div className="row">
      <div className="col-12 new-design">
        <div className="row mb-3">
          <div className="col-12">
            <DropDownList
              name={props.filterName}
              data={filterPeriodData}
              defaultItem={{ text: "All", id: "" }}
              defaultValue={periodData}
              value={periodData}
              onChange={handlePeriodChange}
              textField="text"
              label="Period"
            />
          </div>
          {isCustom && (
            <div className="col-12">
              <DateRangePicker value={dateRange} onChange={handleSearchDateChange} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FilterDate;
