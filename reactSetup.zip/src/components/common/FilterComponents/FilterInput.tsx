import { Input, InputChangeEvent } from "@progress/kendo-react-inputs";
import { useState } from "react";

interface props {
  filterName: string;
  filterLabel: string;
  onFilterChange: (filter: { name: string; value: string }) => void;
}

const FilterDate = (props: props) => {
  const [inputValue, setInputValue] = useState<string | null>(null);

  const handlePeriodChange = (e: InputChangeEvent) => {
    const value = e.value;
    setInputValue(value);
    setFilterInRedux();
  };

  const setFilterInRedux = () => {
    const filter: { name: string; value: string } = {
      name: props.filterName,
      value: inputValue,
    };
    props.onFilterChange(filter);
  };

  return (
    <div className="row new-design">
      <div className="col-12">
        <Input label={props.filterLabel} name={props.filterName} value={inputValue} onChange={handlePeriodChange} />
      </div>
    </div>
  );
};

export default FilterDate;
