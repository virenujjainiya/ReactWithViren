import { DropDownList, DropDownListChangeEvent } from "@progress/kendo-react-dropdowns";
import { useState } from "react";

import { filterPeriodData } from "@src/components/pages/Order History/Constant";

interface props {
  filterName: string;
  filterLabel: string;
  dropDownListData: [];
  onFilterChange: (filter: { name: string; value: string }) => void;
  dataItemkey?: string;
  textField?: string;
  defaultItem: string | { id: string; text: string };
}

const FilterDropDown = (props: props) => {
  const [dropDownValue, setDropDownValues] = useState<{ id: string; text: string } | null | string>(null);

  const handlePeriodChange = (e: DropDownListChangeEvent) => {
    const value: { id: string; text: string } = e.value;
    setDropDownValues(value);
    setFilterInRedux();
  };

  const setFilterInRedux = () => {
    let filter: { name: string; value: string };
    props.onFilterChange(filter);
  };

  return (
    <div className="row new-design">
      <div className="col-12">
        <DropDownList
          name={props.filterName}
          data={filterPeriodData}
          defaultItem={props.defaultItem}
          defaultValue={dropDownValue}
          value={dropDownValue}
          onChange={handlePeriodChange}
          textField={props.textField}
          label={props.filterLabel}
        />
      </div>
    </div>
  );
};

export default FilterDropDown;
