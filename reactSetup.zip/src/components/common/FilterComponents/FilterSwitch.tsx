import { Switch, SwitchChangeEvent } from "@progress/kendo-react-inputs";
import { Label } from "@progress/kendo-react-labels";
import { useState } from "react";

interface props {
  filterName: string;
  filterLabel: string;
  onFilterChange: (filter: { name: string; value: boolean }) => void;
}

const FilterSwitch = (props: props) => {
  const [inputValue, setInputValue] = useState<boolean | null>(null);

  const handlePeriodChange = (e: SwitchChangeEvent) => {
    const value = e.value;
    setInputValue(value);
    setFilterInRedux();
  };

  const setFilterInRedux = () => {
    const filter: { name: string; value: boolean } = {
      name: props.filterName,
      value: inputValue,
    };
    props.onFilterChange(filter);
  };

  return (
    <div className="row new-design">
      <div className="col-12">
        <Label>{props.filterLabel}</Label>
        <Switch name={props.filterName} value={inputValue} onChange={handlePeriodChange} />
      </div>
    </div>
  );
};

export default FilterSwitch;
