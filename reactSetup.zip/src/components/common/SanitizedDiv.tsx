import { useLayoutEffect, useRef } from "react";
import { getPurifyDom } from "@src/helpers/utils";

interface props {
  htmlString: string;
  className?: string;
}

export const SanitizedDiv = ({ htmlString, className }: props) => {
  const ref = useRef<HTMLPreElement>();

  useLayoutEffect(() => {
    ref.current.innerHTML = getPurifyDom(htmlString);
  }, [htmlString]);

  return <pre style={{ fontSize: "inherit" }} className={className + " " + "text-wrap mb-0"} ref={ref}></pre>;
};
