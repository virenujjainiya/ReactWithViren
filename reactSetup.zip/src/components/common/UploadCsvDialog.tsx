import { Button } from "@progress/kendo-react-buttons";
import { Tooltip } from "@progress/kendo-react-tooltip";
import {
  ExternalDropZone,
  Upload,
  UploadFileStatus,
  UploadListItemProps,
  UploadOnBeforeUploadEvent,
  UploadOnStatusChangeEvent,
} from "@progress/kendo-react-upload";
import React, { useState, useRef } from "react";
import { authHeader } from "../../helpers/auth-header";
import { useNotification } from "../../hooks/useNotification";
import CustomDialog from "./Dialog/CustomDialog";
import LoadingPanel from "./LoadingPanel";

interface IUploadCsvDialogProps {
  showUpload: boolean;
  setShowUpload: (show: boolean) => void;
  dialogTitle: string;
  handlePluginExportToCsv: () => void;
  successCallback: () => void;
  saveUrl: string;
}

const UploadCsvDialog: React.FC<IUploadCsvDialogProps> = ({
  showUpload,
  setShowUpload,
  dialogTitle,
  handlePluginExportToCsv,
  successCallback,
  saveUrl,
}) => {
  const uploadRef = useRef<Upload>(null);
  const [uploadLoader, setUploadLoader] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<any>(null);

  const successNotification = useNotification({ type: "success" });
  const errorNotification = useNotification({ type: "error" });

  const closeUploadDialog = () => {
    setShowUpload(false);
  };

  const changeStatusStyle = () => {
    const statusDiv = document.querySelector(".k-upload-status > span");
    if (statusDiv) {
      const div = document.querySelector(".k-upload-status");
      if (div instanceof HTMLElement && statusDiv.classList.contains("k-svg-i-exclamation-circle")) {
        div.style.color = "#f31700";
        div.innerHTML = '<span class="k-icon k-font-icon k-i-exception"></span>Failed';
      } else if (div instanceof HTMLElement && statusDiv.classList.contains("k-svg-i-check")) {
        div.style.color = "#37b400";
      }
    }
  };

  const onUploadStatusChange = (e: UploadOnStatusChangeEvent) => {
    const file = e.affectedFiles[0];
    const fileResponse: {
      data: string;
      error: string;
    } = e.response?.response;

    if (file && file.status === UploadFileStatus.Uploaded) {
      successNotification("Uploaded Successfully");
      successCallback();
    } else if (fileResponse && fileResponse.data === "You are not authorized for this action.") {
      closeUploadDialog();
      setUploadLoader(false);
      errorNotification("You are not authorized for this action.");
    } else if (fileResponse && fileResponse.error) {
      errorNotification(fileResponse.error || "Failed to upload");
    }

    setUploadLoader(false);
    setUploadedFile(null);
    changeStatusStyle();
  };

  const onBeforeUpload = (e: UploadOnBeforeUploadEvent) => {
    e.headers = {
      Authorization: "Bearer " + authHeader.getToken(),
      "X-Vendor": authHeader.getXVendor(),
    };
    setUploadLoader(true);
  };

  if (showUpload) {
    return (
      <CustomDialog
        show={showUpload}
        className="small-window integration-config-form-dialog"
        title={dialogTitle}
        onClose={closeUploadDialog}
      >
        <div className="row custom-file-upload-container">
          {uploadLoader && (
            <div className="k-dialog-wrapper">
              <div className="k-overlay"></div>
              <div className="position-relative">
                <LoadingPanel />
              </div>
            </div>
          )}
          <div className="d-flex gap-4 justify-content-center mb-3">
            <Tooltip position="top">
              <div title={!uploadedFile ? "Select File" : ""}>
                <Button
                  size={"small"}
                  icon="upload"
                  title={!uploadedFile ? "Select File" : ""}
                  disabled={!uploadedFile}
                  onClick={() => uploadRef.current?.onUpload()}
                >
                  Upload
                </Button>
              </div>
            </Tooltip>
            <Button size={"small"} icon="download" themeColor="primary" onClick={handlePluginExportToCsv}>
              Download Template
            </Button>
          </div>
          {!uploadedFile && (
            <div className="col-12">
              <ExternalDropZone
                customHint="Drag and Drop here file to upload"
                uploadRef={uploadRef}
                customNote="Only CSV file are allowed"
              />
            </div>
          )}
          <div className="col-12 position-relative">
            <Upload
              ariaLabelledBy="Select File"
              ref={uploadRef}
              onAdd={(e) => {
                if (!e.newState[0].validationErrors) {
                  setUploadedFile(e.newState);
                }
              }}
              batch={false}
              multiple={false}
              className="custom-file-upload"
              showActionButtons={false}
              onBeforeUpload={onBeforeUpload}
              onStatusChange={onUploadStatusChange}
              defaultFiles={[]}
              restrictions={{
                allowedExtensions: [".csv"],
              }}
              selectMessageUI={() => {
                return <div>Select File</div>;
              }}
              withCredentials={false}
              autoUpload={false}
              listItemUI={(props: UploadListItemProps) => (
                <CustomListItemUI {...props} setUploadedFile={setUploadedFile} />
              )}
              saveUrl={saveUrl}
            />
          </div>
        </div>
      </CustomDialog>
    );
  }

  return null;
};

export default UploadCsvDialog;

interface ICustomListItemUIProps extends UploadListItemProps {
  setUploadedFile: (file: any) => void;
}

const CustomListItemUI: React.FC<ICustomListItemUIProps> = ({ files, setUploadedFile }) => {
  return (
    <div className="w-100">
      {files.map((file) => (
        <div className="k-file" key={file.name}>
          <div className="k-file-single">
            <span className="k-file-group-wrapper">
              <span className="k-file-group k-icon k-font-icon k-i-file"> </span>
            </span>
            <span className="k-file-name-size-wrapper">
              <span className="k-file-name  k-file-name-invalid" title={file.name}>
                {file.name}
              </span>
              {file.validationErrors && (
                <span className="k-file-validation-message k-text-error">
                  {file.validationErrors[0] === "invalidFileExtension" && "Only CSV file is supported."}
                </span>
              )}
            </span>

            <strong className="k-upload-status">
              <button
                type="button"
                tabIndex={-1}
                onClick={() => {
                  setUploadedFile(null);
                  // Assuming onCancel and file.uid are passed down from parent component
                  // props.onCancel(file.uid);
                }}
                className="k-button k-button-icon k-flat k-upload-action"
              >
                <span aria-label="Remove" title="Remove" className="k-icon k-font-icon k-delete k-i-x"></span>
              </button>
            </strong>
          </div>
        </div>
      ))}
    </div>
  );
};
