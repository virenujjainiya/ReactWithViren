import { ReactElement } from "react";
import { Navigate } from "react-router-dom";
import { loggedInUser } from "@src/helpers/loggedInUser";
import useIsUserLoggedInSSO from "@src/hooks/useIsUserLoggedInSSO";

interface IAuthWrapper {
  children: ReactElement;
}

const AuthWrapper = ({ children }: IAuthWrapper) => {
  const user = loggedInUser.getUser();
  const { isLoggedIn } = useIsUserLoggedInSSO();

  if (user && isLoggedIn) {
    return children;
  }

  return <Navigate to="/authenticate" />;
};

export default AuthWrapper;
