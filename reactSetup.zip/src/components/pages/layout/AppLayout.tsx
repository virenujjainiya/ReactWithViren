import { Drawer, DrawerContent, DrawerItem, DrawerItemProps, DrawerSelectEvent } from "@progress/kendo-react-layout";
import React, { useCallback, useEffect, useState } from "react";
import { Link, Outlet } from "react-router-dom";
import { ShowNotification } from "../../common";
import AppHeader from "./AppHeader";
import Navigation, { INavigation } from "./Navigation";

const AppLayout: React.FC = () => {
  // const dispatch: Dispatch<any> = useDispatch();
  // // const show = useSelector(() => props.sidebar.sidebarShow);

  const [show, setShow] = useState(true);
  const [items, setItems] = useState<INavigation[]>(Navigation);
  // const navigate = useNavigate();

  // const navigate = useNavigate();
  // const location = useLocation();

  // const [currentTab,setCurrentTab]=useState(undefined as any);

  // const selected = setSelectedItem(location.pathname);

  // const isValidRoute = (path, pathname, variable) => {

  //     const path1 = path.split('/');
  //     const idIndex = variable && path1.indexOf(variable);
  //     const path2 = pathname.split('/')
  //     if (path1.length && path1.length === path2.length) {
  //         if (path.length > 4) {
  //             const temp1 = path1.filter((_data, index) => index !== idIndex);
  //             const temp2 = path2.filter((_data, index) => index !== idIndex);
  //             return JSON.stringify(temp1) === JSON.stringify(temp2);
  //         } else {
  //             return path1[1] === path2[1]
  //         }
  //     } else {
  //         return false
  //     }

  // }

  // useEffect(() => {
  //     const user = loggedInUser.getUser();

  //     if (user) {
  //         const isValid = routes.find(attr => {
  //             return isValidRoute("/" + attr.path, location.pathname, attr.variable)
  //         });
  //         // eslint-disable-next-line react-hooks/exhaustive-deps
  //        !(isValid) && navigate('/dashboard');
  //     }

  //     //if (!user) {
  //     //    window.location.href = "/login";
  //     //}
  //     //else {
  //     //    const isValid = routes.find(attr => {
  //     //        return isValidRoute("/" + attr.path, location.pathname, attr.variable)
  //     //    });
  //     //    if (user && user.role) {
  //     //        !(isValid) && navigate('/dashboard');
  //     //    }
  //     //}
  //     // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, [location.pathname])

  // useEffect(() => {
  //     window.addEventListener('storage', e => {
  //         if (e.key === 'user' && e.oldValue && !e.newValue) {
  //             dispatch(authActions.logout());
  //         }
  //     });
  //     // eslint-disable-next-line react-hooks/exhaustive-deps
  // }, []);

  // useEffect(() => {
  //     if (props.allTabsLogout) {
  //         window.location.href = '/login';
  //     }
  // }, [props.allTabsLogout]);

  // useEffect(()=>{

  //     const path=location.pathname;

  //     if(path && path.length>0){

  //         const currentRoute=routes.find(route=>{
  //                     return isSystemRouteMatchWithCurrentRoute("/" + route.path, path, route.variable)
  //             }
  //         );
  //         const userDetails = loggedInUser.getUser();
  //         const userId = userDetails ? userDetails.id : 0 ;
  //         const isUpdatingProfile = (currentRoute?.name==="editUser" && userId && path.includes(userId.toString()));

  //         if((currentRoute && !isUpdatingProfile)){
  //             dispatch(authActions.checkRole(currentRoute?.roles));
  //         }

  //     }
  // // eslint-disable-next-line react-hooks/exhaustive-deps
  // },[location.pathname])

  useEffect(() => {
    const itemToExpand = Navigation.map((menuItem) =>
      location.pathname.includes(menuItem.route) && menuItem.isParent
        ? { ...menuItem, expanded: true }
        : { ...menuItem },
    );
    setItems(itemToExpand);

    // check for the user and logout if not found in localstorage.
    // const user = loggedInUser.getUser();
    // if (!user) {
    //   navigate('/login');
    // }
  }, [Navigation]);

  const CustomItem = (cust_item: DrawerItemProps) => {
    const { isLogo, visible, ...other } = cust_item;
    const arrowDir = cust_item.expanded ? "k-i-arrow-chevron-down" : "k-i-arrow-chevron-right";

    if (visible === false) {
      return null;
    }

    if (isLogo) {
      return (
        <Link to={"#"} className={cust_item.className ? cust_item.className : ""}>
          <DrawerItem disabled={true} {...other}>
            <span className={"k-icon k-font-icon n-icon " + cust_item.icon} />
            <span className={"k-item-text"}>{cust_item.text}</span>
          </DrawerItem>
        </Link>
      );
    }

    return (
      <Link to={cust_item.route} className={cust_item.className ? cust_item.className : ""}>
        <DrawerItem {...other}>
          {cust_item?.icon?.length > 0 && <span className={"k-icon k-font-icon n-icon " + cust_item.icon} />}
          <span className={"k-item-text"}>{cust_item.text}</span>
          {cust_item.isParent && <span className={"k-icon k-font-icon parent-expand-icon " + arrowDir} />}
        </DrawerItem>
      </Link>
    );
  };

  const handleTabSelect = useCallback(
    (ev: DrawerSelectEvent) => {
      const { props: currentItem } = ev.itemTarget;
      const { isParent, isChild, expanded, route: currentItem_route } = currentItem;
      const nextExpanded = !expanded;

      const newData = items.map((item) => {
        const { expanded: currentExpanded, route } = item;
        const isCurrentItem = currentItem_route === route;

        return {
          ...item,
          selected: isCurrentItem,
          expanded: isCurrentItem && isParent ? nextExpanded : isChild ? currentExpanded : false,
          route,
        };
      });

      setItems(newData);
    },
    [items, setItems],
  );

  const data = items.map((item) => {
    const { parentId, ...others } = item;

    const isSelected = location.pathname === "/" + item.route;

    if (parentId !== undefined) {
      const parent = items.find((parent) => parent.id === parentId);

      if (!show) {
        return {
          ...others,
          selected: isSelected,
          visible: false,
        };
      }

      return {
        ...others,
        selected: isSelected,
        visible: parent && parent.expanded,
      };
    }

    return { ...item, selected: isSelected };
  });

  return (
    <div className="c-app c-default-layout">
      <div className="c-wrapper">
        {/*<DefaultHeader />*/}
        <Drawer
          expanded={show}
          position={"start"}
          mode="push"
          width={270}
          mini={true}
          miniWidth={75}
          items={data}
          onSelect={handleTabSelect}
          item={CustomItem}
        >
          <DrawerContent>
            <div className="main-content">
              <AppHeader show={show} setShow={setShow} />
              <div className="main-content-container">
                <Outlet />
              </div>
            </div>
          </DrawerContent>
        </Drawer>
        <ShowNotification />
      </div>
    </div>
  );
};

export default AppLayout;
