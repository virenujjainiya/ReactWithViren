export interface INavigation {
  id: number;
  text: string;
  route: string;
  icon?: string;
  separator?: boolean;
  className?: string;
  parentId?: number;
  isLogo?: boolean;
  expanded?: boolean;
  isChild?: boolean;
  isParent?: boolean;
}

const Navigation: INavigation[] = [
  {
    id: 1,
    text: "",
    icon: "n-i-logo",
    route: "#",
    separator: false,
    isLogo: true,
    className: "vendor-logo gap-0",
  },
  {
    id: 2,
    text: "Order History",
    route: "order-history",
    icon: " k-i-js",
  },
  {
    id: 3,
    text: "Vendor",
    route: "vendor",
    icon: " k-i-cart",
  },
];

export default Navigation;
