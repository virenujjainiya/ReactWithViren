import { filterBy, FilterDescriptor } from "@progress/kendo-data-query";
import { Button } from "@progress/kendo-react-buttons";
import { ComboBox, ComboBoxChangeEvent, ComboBoxFilterChangeEvent } from "@progress/kendo-react-dropdowns";
import { AppBar } from "@progress/kendo-react-layout";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Location, useLocation } from "react-router-dom";
import { config } from "@src/config";
import { loggedInUser } from "@src/helpers/loggedInUser";
import { isSystemRouteMatchWithCurrentRoute } from "@src/helpers/utils";
import IVendor from "@src/interface/common/IVendor";
import { authorizedRoutes, IAuthorizedRoutes } from "@src/routes";
import { vendorData } from "../Order History/Constant";

interface IAppHeader {
  show: boolean;
  setShow: Dispatch<SetStateAction<boolean>>;
}

const AppHeader = (props: IAppHeader) => {
  const { setShow, show } = props;

  const location: Location = useLocation();

  const handleLogOut = () => {
    window.location.href = config.ssoUrl;
    loggedInUser.removeUser();
  };

  const getHeaderNameFromPathName = (pathname: string) => {
    const header: IAuthorizedRoutes = authorizedRoutes.find((attr) => {
      return isSystemRouteMatchWithCurrentRoute("/" + attr.path, pathname, attr.variable);
    });
    return header && header.headerName;
  };

  const handleToggle = () => {
    setShow((show) => !show);
  };

  const [vendor, setVendor] = useState<IVendor>(null);
  const [vendorList, setVendorList] = useState<IVendor[]>(vendorData);

  useEffect(() => {
    const user = loggedInUser.getUser();
    if (user && user.vendor) {
      setVendor(user.vendor);
    }
  }, []);
  const handleVendorChange = (event: ComboBoxChangeEvent) => {
    const vendorValue: IVendor = event.value;

    setVendor(vendorValue);

    // if (event && event.value) {
    //   if (event.nativeEvent.code === "Enter") {
    //   } else if (event.nativeEvent.type === "click") {

    //   }
    // }
  };

  const getPlaceHolderForVendor = () => {
    const vendor = loggedInUser.getDefaultVendor();
    return vendor && vendor.longName ? vendor.longName : "";
  };

  const filterChange = (event: ComboBoxFilterChangeEvent) => {
    event.target.focus();
    if (event && event.filter) {
      setVendorList(filterData(event.filter));
    }
  };

  const filterData = (filter: FilterDescriptor) => {
    const vendors =
      vendorData &&
      vendorData.filter((attr) => {
        return attr.code !== null && attr.longName !== null;
      });
    return filterBy(vendors, filter);
  };

  return (
    <AppBar themeColor="inherit" className="app-header-container">
      <div className={`round-border ${show ? "" : "active-round-button"}`}>
        <span
          onClick={handleToggle}
          className={`k-icon k-font-icon p-4 cursor-pointer ${
            show ? "k-i-arrow-chevron-left  " : "k-i-arrow-chevron-right"
          } `}
        ></span>
      </div>
      <div>
        <h4 className="mb-0">{getHeaderNameFromPathName(location.pathname)}</h4>
      </div>
      <div className="d-flex gap-3">
        <ComboBox
          style={{ width: 400 }}
          disabled={false}
          data={vendorList || []}
          textField="longName"
          dataItemKey="code"
          value={vendor}
          onChange={handleVendorChange}
          allowCustom={false}
          filterable={true}
          onFilterChange={filterChange}
          placeholder={getPlaceHolderForVendor()}
          loading={false}
          onClose={handleVendorChange}
        />
        <Button onClick={handleLogOut}>Log Out</Button>
      </div>
    </AppBar>
  );
};

export default AppHeader;
