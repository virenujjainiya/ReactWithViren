import { Button } from "@progress/kendo-react-buttons";
import { Grid, GridColumn, GridCustomCellProps } from "@progress/kendo-react-grid";
import { TabStrip, TabStripTab } from "@progress/kendo-react-layout";
import { QueryStatus } from "@reduxjs/toolkit/query";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AddressCard from "@src/components/common/Card/AddressCard";
import DetailRow from "@src/components/common/Card/DetailRow";
import CustomAccordion from "@src/components/common/CustomAccordion";
import PricingCell from "@src/components/common/CustomCells/PricingCell";
import LoadingPanel from "@src/components/common/LoadingPanel";
import { IOrderDetailProps, IOrderGridProps } from "@src/interface/Order/OrderTypes";
import { useGetOrderHistoryMutation } from "@src/redux/reducers/api/orderHIstoryApi";
import backArrow from "../../../../assets/icon/arrow-left.svg";

const Header = () => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="d-flex justify-content-between">
      <img src={backArrow} width={25} className="cursor-pointer" onClick={handleBack}></img>
      <Button themeColor="primary">Re-order</Button>
    </div>
  );
};

interface IUseGetOrderHistoryMutation {
  data: IOrderDetailProps;
  status: QueryStatus.uninitialized;
  error?: undefined;
  endpointName?: string;
  startedTimeStamp?: undefined;
  fulfilledTimeStamp?: undefined;
  isLoading;
}
const DetailPageOfOrderHistory = () => {
  const [open, setOpen] = useState(true);
  const [active, setActive] = useState(0);

  const [getOrderHistory, { isLoading: gettingOrderHistory, data }] =
    useGetOrderHistoryMutation<IUseGetOrderHistoryMutation>();

  const [orderDetail, setOrderDetails] = useState<IOrderDetailProps | undefined>(undefined);

  useEffect(() => {
    setOrderDetails(data);
  }, [data]);
  useEffect(() => {
    void getOrderHistory({});
  }, []);

  return (
    <div className="d-flex gap-3 flex-column position-relative">
      {gettingOrderHistory && <LoadingPanel />}
      <Header></Header>
      <div className="d-flex gap-3 flex-column justify-content-between">
        <CustomAccordion subtitle="" title="Order Details" isOpen={open} onClick={() => setOpen(!open)}>
          <div>
            {/* {dataLoading && <LoadingPanel />} */}
            {orderDetail && Object.keys(orderDetail).length > 0 && (
              <div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.orderNo} label={"Order No"} />
                  <DetailRow value={orderDetail.po} label={"PO"} />
                  <DetailRow value={orderDetail.source} label={"Source"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.orderType} label={"Order Type"} />
                  <DetailRow value={orderDetail.customerID} label={"Customer Id"} />
                  <DetailRow value={orderDetail.vendorNo} label={"Vendor No"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.location} label={"Location"} />
                  <DetailRow value={orderDetail.status} label={"Status"} />
                  <DetailRow value={orderDetail.repName} label={"Sales Rep"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.agency} label={"Agency"} />
                  <DetailRow value={orderDetail.promo} label={"Promotion Code"} />
                  <DetailRow value={orderDetail.orderClass} label={"Order Class"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.brand} label={"Brand"} />
                  <DetailRow value={orderDetail.terms} label={"Terms"} />
                  <DetailRow value={orderDetail.paymentMethod} label={"Payment Method"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.shipMethod} label={"Ship Method"} />
                  <DetailRow value={orderDetail.shipService} label={"Ship Service"} />
                  <DetailRow value={orderDetail.whsAcctgId} label={"WHS Acctg Id"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.giftMessage} label={"Gift Message"} />
                  <DetailRow value={orderDetail.shippingLabel} label={"Ship Label"} />
                  <DetailRow value={orderDetail.packingSlip} label={"Packing Slip"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.orderDate} label={"Order Date"} />
                  <DetailRow value={orderDetail.shipDate} label={"Ship Date"} />
                  <DetailRow value={orderDetail.cancelDate} label={"Cancel Date"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.receiptDate} label={"Receipt Date"} />
                  {orderDetail.discountType && orderDetail.discountType === "PERCENTAGE" ? (
                    <DetailRow value={orderDetail.discount} label={"Discount"} isPricing isPercentage />
                  ) : (
                    <DetailRow value={orderDetail.discount} label={"Discount"} isPricing />
                  )}
                  <DetailRow value={orderDetail.discountType} label={"Discount Type"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.discountCode} label={"Discount Code"} />
                  <DetailRow value={orderDetail.freight} label={"Freight"} isPricing />
                  <DetailRow value={orderDetail.tax} label={"Tax"} isPricing />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.taxCode} label={"Tax Code"} />
                  <DetailRow value={orderDetail.total} label={"Total"} isPricing />
                  <DetailRow value={orderDetail.comments} label={"Comments"} />
                </div>
                <div className="row mb-4">
                  <DetailRow value={orderDetail.subTotal} label={"Sub Total"} isPricing />
                  <DetailRow value={orderDetail.id} label={"Internal Id"} />
                </div>
              </div>
            )}
          </div>
        </CustomAccordion>
        <div className="d-flex justify-content-between gap-3">
          <AddressCard details={orderDetail?.billingAddress} isLoading={false} title={"Billing Details"} />
          <AddressCard details={orderDetail?.shippingAddress} isLoading={false} title={"Shipping Details"} />
        </div>
        <TabStrip onSelect={(e) => setActive(e.selected)} selected={active}>
          <TabStripTab contentClassName="w-100" title="Line Items">
            <div className="row mb-4">
              <div className="col-12">
                <div className="gridInnerWrapper">
                  {!(orderDetail && orderDetail?.lineItems)}
                  <Grid
                    style={{ maxHeight: 500 }}
                    resizable={true}
                    pageable={false}
                    data={
                      orderDetail?.lineItems
                        ? orderDetail.lineItems.slice().sort((a, b) => a.lineNumber - b.lineNumber)
                        : []
                    }
                  >
                    <GridColumn field="lineNumber" title="Line No." width="100px" />
                    <GridColumn field="sku" title="SKU" width="150px" />
                    <GridColumn field="description" title="Description" width="200px" />
                    <GridColumn
                      field="price"
                      title="Price"
                      width="100px"
                      cell={(props: GridCustomCellProps) => {
                        const myData = props.dataItem as IOrderGridProps;
                        const priceValue = myData.amount;
                        return <PricingCell priceValue={priceValue} className={""} nodata={""} />;
                      }}
                    />
                    <GridColumn field="quantity" title="Quantity" width="100px" />
                    <GridColumn field="quantityShipped" title="Shipped QTY" width="130px" />
                    <GridColumn field="quantitySent" title="Sent QTY" width="100px" />
                    <GridColumn field="upc" title="UPC" width="150px" />
                    <GridColumn field="retItem" title="Ret Item" width="150px" />
                    <GridColumn field="sizeOrColor" title="Size / Color" width="150px" />
                    <GridColumn field="color" title="Color" width="150px" />
                  </Grid>
                </div>
              </div>
            </div>
          </TabStripTab>
        </TabStrip>
      </div>
    </div>
  );
};

export default DetailPageOfOrderHistory;
