import { Button } from "@progress/kendo-react-buttons";
import { Grid, GridColumn } from "@progress/kendo-react-grid";
import { Card, CardBody, CardHeader } from "@progress/kendo-react-layout";
import { QueryStatus } from "@reduxjs/toolkit/query";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AddressCard from "@src/components/common/Card/AddressCard";
import DetailRow from "@src/components/common/Card/DetailRow";
import PricingCell from "@src/components/common/CustomCells/PricingCell";
import LoadingPanel from "@src/components/common/LoadingPanel";
import { IOrderDetailProps } from "@src/interface/Order/OrderTypes";
import { useGetOrderHistoryMutation } from "@src/redux/reducers/api/orderHIstoryApi";
import backArrow from "../../../../assets/icon/arrow-left.svg";

const Header = () => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div className="d-flex justify-content-between">
      <img src={backArrow} width={25} className="cursor-pointer" onClick={handleBack}></img>
      <Button themeColor="primary">Re-order</Button>
    </div>
  );
};

interface IUseGetOrderHistoryMutation {
  data: IOrderDetailProps;
  status: QueryStatus.uninitialized;
  error?: undefined;
  endpointName?: string;
  startedTimeStamp?: undefined;
  fulfilledTimeStamp?: undefined;
  isLoading;
}

const OrderHistoryDetailPage = () => {
  const [active, setActive] = useState("lineItems");

  const [getOrderHistory, { isLoading: gettingOrderHistory, data }] =
    useGetOrderHistoryMutation<IUseGetOrderHistoryMutation>();

  const [orderDetail, setOrderDetails] = useState<IOrderDetailProps | undefined>(undefined);

  useEffect(() => {
    setOrderDetails(data);
  }, [data]);
  useEffect(() => {
    void getOrderHistory({});
  }, []);

  const isOrderContainsEdi = (edi) => {
    const data = Object.keys(edi).map((attr) => edi[attr] != null);
    return data.includes(true);
  };

  return (
    <div className="d-flex gap-3 flex-column position-relative">
      {gettingOrderHistory && <LoadingPanel />}
      <Header></Header>
      <div className="d-flex gap-3 flex-column justify-content-between">
        <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xxl-12 col-xl-12 ">
          <Card className="card-border mb-3">
            <CardHeader>Order Details</CardHeader>
            <CardBody>
              {orderDetail && Object.keys(orderDetail).length > 0 && (
                <div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.orderNo} label={"Order No"} />
                    <DetailRow value={orderDetail.po} label={"PO"} />
                    <DetailRow value={orderDetail.source} label={"Source"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.orderType} label={"Order Type"} />
                    <DetailRow value={orderDetail.customerID} label={"Customer Id"} />
                    <DetailRow value={orderDetail.vendorNo} label={"Vendor No"} />
                  </div>
                  <div className="row mb-4">
                    {/* <DetailRow value={orderDetail.vendorCustomerId} label={"Vendor Customer Id"} /> */}
                    <DetailRow value={orderDetail.location} label={"Location"} />
                    <DetailRow value={orderDetail.status} label={"Status"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.repName} label={"Sales Rep"} />
                    <DetailRow value={orderDetail.agency} label={"Agency"} />
                    <DetailRow value={orderDetail.promo} label={"Promotion Code"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.orderClass} label={"Order Class"} />
                    <DetailRow value={orderDetail.brand} label={"Brand"} />
                    <DetailRow value={orderDetail.terms} label={"Terms"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.paymentMethod} label={"Payment Method"} />
                    <DetailRow value={orderDetail.shipMethod} label={"Ship Method"} />
                    <DetailRow value={orderDetail.shipService} label={"Ship Service"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.whsAcctgId} label={"WHS Acctg Id"} />
                    <DetailRow value={orderDetail.giftMessage} label={"Gift Message"} />
                    <DetailRow value={orderDetail.shippingLabel} label={"Ship Label"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.packingSlip} label={"Packing Slip"} />
                    <DetailRow value={orderDetail.orderDate} label={"Order Date"} />
                    <DetailRow value={orderDetail.shipDate} label={"Ship Date"} />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.cancelDate} label={"Cancel Date"} />
                    <DetailRow value={orderDetail.receiptDate} label={"Receipt Date"} />
                    {orderDetail.discountType && orderDetail.discountType === "PERCENTAGE" ? (
                      <DetailRow value={orderDetail.discount} label={"Discount"} isPricing isPercentage />
                    ) : (
                      <DetailRow value={orderDetail.discount} label={"Discount"} isPricing />
                    )}
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.discountType} label={"Discount Type"} />
                    <DetailRow value={orderDetail.discountCode} label={"Discount Code"} />
                    <DetailRow value={orderDetail.freight} label={"Freight"} isPricing />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.tax} label={"Tax"} isPricing />
                    <DetailRow value={orderDetail.taxCode} label={"Tax Code"} />
                    <DetailRow value={orderDetail.total} label={"Total"} isPricing />
                  </div>
                  <div className="row mb-4">
                    <DetailRow value={orderDetail.comments} label={"Comments"} />
                    <DetailRow value={orderDetail.subTotal} label={"Sub Total"} isPricing />
                    <DetailRow value={orderDetail.id} label={"Internal Id"} />
                  </div>
                </div>
              )}
            </CardBody>
          </Card>
          {orderDetail &&
            (orderDetail.ccName ||
              orderDetail.ccNumber ||
              orderDetail.ccToken ||
              orderDetail.ccType ||
              orderDetail.ccExp ||
              orderDetail.ccCvv) && (
              <Card className="card-border mb-3">
                <CardHeader>
                  <div className="ms-2">CC Details</div>
                </CardHeader>
                <CardBody>
                  <>
                    <div className="row mb-2">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Name</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccName ? orderDetail.ccName : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Number</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccNumber ? orderDetail.ccNumber : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                    </div>
                    <div className="row mb-2">
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Token</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccToken ? orderDetail.ccToken : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Type</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccType ? orderDetail.ccType : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Exp</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccExp ? orderDetail.ccExp : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                      <div className="col-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
                        <div className="row">
                          <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12 detail-font">Cvv</div>
                          <strong>
                            <div className="col-12 col-md-12 col-sm-12 col-lg-12 col-xl-12">
                              {orderDetail?.ccCvv ? orderDetail.ccCvv : " - "}
                            </div>
                          </strong>
                        </div>
                      </div>
                    </div>
                  </>
                  {/* {!props?.stagingOrder?.ccNumber &&
                      <div className="row mb-2">
                      <div className="col-12">-----</div>
                      </div>
                  } */}
                </CardBody>
              </Card>
            )}

          <div className="mb-3">
            <AddressCard details={orderDetail?.billingAddress} isLoading={false} title={"Billing Details"} />
          </div>
          <div className="mb-3">
            <AddressCard details={orderDetail?.shippingAddress} isLoading={false} title={"Shipping Details"} />
          </div>

          {(orderDetail !== null || orderDetail !== undefined) && (
            <div className="col-12">
              <div className="nav-grid w-100 mb-3">
                <div className=" p-2 nav-items d-flex">
                  <div onClick={() => setActive("lineItems")} className={active === "lineItems" ? "active-item" : ""}>
                    Line Items
                  </div>
                  <div onClick={() => setActive("packs")} className={active === "packs" ? "active-item" : ""}>
                    Packs
                  </div>
                  <div onClick={() => setActive("edi")} className={active === "edi" ? "active-item" : ""}>
                    EDI
                  </div>
                  <div
                    onClick={() => setActive("customFields")}
                    className={active === "customFields" ? "active-item" : ""}
                  >
                    Custom Fields
                  </div>
                  <div onClick={() => setActive("payments")} className={active === "payments" ? "active-item" : ""}>
                    Payments
                  </div>
                </div>
              </div>
              {active === "edi" && (
                <div className="row mb-4">
                  <div className="col-12">
                    <div className="gridInnerWrapper position-relative">
                      <Grid resizable={true} data={isOrderContainsEdi(orderDetail.edi) ? [orderDetail.edi] : []}>
                        <GridColumn field="distributionCenter" title="Distribution center" width="250px" />
                        <GridColumn field="san" title="SAN" width="250px" />
                        <GridColumn field="department" title="Department" width="250px" />
                        <GridColumn field="door" title="Door" width="250px" />
                      </Grid>
                    </div>
                  </div>
                </div>
              )}
              {active === "customFields" && (
                <div className="row mb-4">
                  <div className="col-12">
                    <div className="gridInnerWrapper">
                      <Grid
                        resizable={true}
                        data={orderDetail?.customFieldsArray ? orderDetail?.customFieldsArray : []}
                      >
                        <GridColumn field="name" title="Name" width="250px" />
                        <GridColumn field="value" title="Value" width="250px" />
                      </Grid>
                    </div>
                  </div>
                </div>
              )}
              {active === "lineItems" && (
                <div className="row mb-4">
                  <div className="col-12">
                    <div className="gridInnerWrapper">
                      <Grid resizable={true} data={orderDetail?.lineItems?.length > 0 ? orderDetail.lineItems : []}>
                        <GridColumn field="lineNumber" title="Line No." width="100px" />
                        <GridColumn field="sku" title="SKU" width="150px" />
                        <GridColumn field="description" title="Description" width="200px" />
                        <GridColumn
                          field="price"
                          title="Price"
                          width="100px"
                          cell={(props) => <PricingCell priceValue={props.dataItem.price} />}
                        />
                        <GridColumn field="quantity" title="Quantity" width="100px" />
                        <GridColumn field="quantityShipped" title="Shipped QTY" width="130px" />
                        <GridColumn field="quantitySent" title="Sent QTY" width="100px" />
                        <GridColumn field="upc" title="UPC" width="150px" />
                        <GridColumn field="retItem" title="Ret Item" width="150px" />
                        <GridColumn field="sizeOrColor" title="Size / Color" width="150px" />
                        <GridColumn field="color" title="Color" width="150px" />
                      </Grid>
                    </div>
                  </div>
                </div>
              )}
              {active === "packs" && (
                <div className="row mb-1">
                  <div className="col-12">
                    <div className="gridInnerWrapper">
                      <Grid resizable={true} data={[]} expandField="expanded">
                        <GridColumn field="packid" title="Pack Id" width="250px" />
                        <GridColumn field="sku" title="Name" width="200px" />
                        <GridColumn field="trackingNumber" title="Tracking No." width="200px" />
                        <GridColumn field="bolNumber" title="BOL" width="150px" />
                        <GridColumn field="shipCarrier" title="Carrier" width="120px" />
                        <GridColumn field="weight" title="Weight" width="120px" />
                      </Grid>
                    </div>
                  </div>
                </div>
              )}
              {active === "payments" && (
                <div className="row mb-1">
                  <div className="col-12">
                    <div className="gridInnerWrapper">
                      <Grid resizable={true} data={orderDetail.payments}>
                        <GridColumn field="transactionId" title="Transaction Id" width="200px" />
                        <GridColumn field="paidDate" title="Paid Date" width="250px" format="{0:dd/MM/yyyy}" />
                        <GridColumn
                          field="amount"
                          title="Amount"
                          width="200px"
                          cell={(props) => <PricingCell priceValue={props.dataItem.amount} />}
                        />
                      </Grid>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default OrderHistoryDetailPage;
