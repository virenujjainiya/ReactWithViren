import { CompositeFilterDescriptor } from "@progress/kendo-data-query";
import { Grid, GridColumn, GridColumnProps, GridCustomCellProps } from "@progress/kendo-react-grid";
import { debounce } from "lodash";
import { memo, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import LoadingPanel from "@src/components/common/LoadingPanel";
import { RootState } from "@src/redux/reducers";
import { useGetAllOrderHistoryMutation } from "@src/redux/reducers/api/orderHIstoryApi";
import {
  handleOrderHistoryFilter,
  handleOrderHistoryPageChange,
  handleOrderHistorySort,
} from "@src/redux/reducers/slice/orderHistory";

const filterGridDataApiCall = debounce((filterEvent: CompositeFilterDescriptor) => {
  //calling an api after debounce
  console.error(filterEvent);
}, 2000);

interface ColumnProps extends GridColumnProps {
  show: boolean;
}

export const OrderGridColumns: ColumnProps[] = [
  {
    field: "id",
    title: "Id",
    width: 80,
    filterable: false,
    show: true,
  },
  {
    field: "orderNo",
    title: "Order No",
    width: 150,
    show: true,
    cell: (props: GridCustomCellProps) => {
      const currentData = props.dataItem as { orderNo: string };
      const orderNo = currentData.orderNo;

      return (
        <td {...props.tdProps}>
          <Link className="link-primary " to={`/order-history/${orderNo}`}>
            {orderNo}
          </Link>
        </td>
      );
    },
  },
  {
    field: "orderType",
    title: "Order Type",
    width: 100,
    show: true,
  },
  {
    field: "source",
    title: "Source",
    width: 150,
    show: true,
  },
  {
    field: "po",
    title: "PO",
    width: 150,
    show: true,
  },
  {
    field: "orderDate",
    title: "Order Date",
    width: 140,
    show: true,
  },
  {
    field: "customer",
    title: "Customer",
    width: 180,
    show: true,
  },
  {
    field: "new",
    title: "New",
    width: 100,
    show: true,
  },
  {
    field: "country",
    title: "Country",
    width: 100,
    show: true,
  },
  {
    field: "shipDate",
    title: "Ship Date",
    width: 140,
    show: true,
  },
  {
    field: "amount",
    title: "Amount",
    width: 100,
    show: true,
  },
  {
    field: "status",
    title: "Status",
    width: 100,
    show: true,
  },
  {
    field: "chain",
    title: "Chain",
    width: 100,
    show: true,
  },
  {
    field: "terms",
    title: "Terms",
    width: 100,
    show: true,
  },
  {
    field: "agency",
    title: "Agency",
    width: 150,
    show: true,
  },
  {
    field: "rep",
    title: "Rep",
    width: 200,
    show: true,
  },
  {
    field: "notes",
    title: "Notes",
    width: 160,
    show: true,
  },
  {
    field: "acctgId",
    title: "Acctg Id",
    width: 100,
    show: true,
  },
  {
    field: "incomingDate",
    title: "Incoming Date",
    width: 200,
    show: true,
  },
  {
    field: "selected",
    title: "Selected",
    width: 100,
    show: true,
  },
];

const OrderHistoryGrid = () => {
  const [getAllOrderHistory, { isLoading: orderHistoryLoading, data: gridData }] = useGetAllOrderHistoryMutation();

  const dispatch = useDispatch();

  const [filterState, setFilterState] = useState<CompositeFilterDescriptor>();

  // const filter = useSelector((state: RootState) => state.orderHistoryAction.filter);
  const sort = useSelector((state: RootState) => state.orderHistoryAction.sort);
  const total = useSelector((state: RootState) => state.orderHistoryAction.total);
  const page = useSelector((state: RootState) => state.orderHistoryAction.page);
  const showFilter = useSelector((state: RootState) => state.orderHistoryAction.showFilter);

  useEffect(() => {
    void getAllOrderHistory();
    return () => {
      filterGridDataApiCall.cancel();
    };
  }, [filterGridDataApiCall]);

  return (
    <div className="position-relative">
      {orderHistoryLoading && <LoadingPanel />}

      <Grid
        style={{ height: "calc(100vh - 165px)", overflow: "auto" }}
        sortable={true}
        pageable={true}
        data={gridData}
        filterable={showFilter}
        onFilterChange={(filterEvent) => {
          dispatch(handleOrderHistoryFilter(filterEvent.filter));
          setFilterState(filterEvent.filter);
          filterGridDataApiCall(filterEvent.filter);
        }}
        onSortChange={(event) => {
          dispatch(handleOrderHistorySort(event.sort));
        }}
        onPageChange={(event) => {
          dispatch(handleOrderHistoryPageChange(event.page));
        }}
        dataItemKey={"id"}
        filter={filterState}
        sort={sort}
        skip={page.skip}
        take={page.take}
        total={total}
        resizable={true}
      >
        {OrderGridColumns.map((column) => {
          let width = column.width;

          if (showFilter) {
            width = column.field === "id" ? width : Number(column.width) * 2;
          }

          return <GridColumn key={column.field} {...column} width={width} />;
        })}
      </Grid>
    </div>
  );
};

export default memo(OrderHistoryGrid);
