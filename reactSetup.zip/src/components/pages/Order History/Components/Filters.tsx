import { Button } from "@progress/kendo-react-buttons";
import { useCallback, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import CustomDialog from "@src/components/common/Dialog/CustomDialog";
import FilterDate from "@src/components/common/FilterComponents/FilterDate";
import { RootState } from "@src/redux/reducers";
import { FilterTag, handleFilterTags, handleShowFilterDialog } from "@src/redux/reducers/slice/orderHistory";

const Filters = () => {
  const [orderFilter, setOrderFilter] = useState<FilterTag[]>([]);

  const showDialog = useSelector((state: RootState) => state.orderHistoryAction.showFilterDialog);

  const dispatch = useDispatch();

  const closeDialog = () => {
    dispatch(handleShowFilterDialog());
  };
  const refreshSearch = () => {
    closeDialog();
  };

  const advancedSearch = () => {
    const payload = orderFilter;
    payload && dispatch(handleFilterTags(payload));
    closeDialog();
  };

  const handleOrderPeriodFilters = useCallback((filter) => {
    if (filter) {
      setOrderFilter((filterData: FilterTag[]) => {
        const newData: FilterTag[] = filterData.map((data: FilterTag) => {
          return data.name === filter.name ? filter : data;
        });
        return newData.length === 0 ? [filter] : newData;
      });
    }
  }, []);

  return (
    <div>
      {showDialog && (
        <CustomDialog width={400} show={showDialog} className="mid-window" title={"More Filters"} onClose={closeDialog}>
          <div className="k-form position-relative">
            {/* {props.periodsLoading && <LoadingPanel />} */}
            <FilterDate
              value={orderFilter.find((filter) => filter.name === "orderPeriod")?.value as { id: string; text: string }}
              filterLabel="Order Period"
              filterName="orderPeriod"
              onFilterChange={handleOrderPeriodFilters}
            />
            <div className="row mt-3">
              <div className="d-flex justify-content-between">
                <div className="d-flex">
                  <Button className="k-button btn-cancle" onClick={closeDialog}>
                    Cancel
                  </Button>
                  <Button
                    type={"button"}
                    onClick={advancedSearch}
                    className="k-button btn-submit ms-2"
                    themeColor="primary"
                  >
                    Search
                  </Button>
                </div>
                <Button icon="refresh" type={"button"} className={"k-button k-button-clear"} onClick={refreshSearch}>
                  Reset
                </Button>
              </div>
            </div>
          </div>
        </CustomDialog>
      )}
    </div>
  );
};

export default Filters;
