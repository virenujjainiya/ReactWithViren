import { Reveal } from "@progress/kendo-react-animation";
import { Button } from "@progress/kendo-react-buttons";
import { Checkbox, InputChangeEvent } from "@progress/kendo-react-inputs";
import { memo, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import col from "@src/assets/icon/columns.svg";
import CustomPopup from "@src/components/common/CustomPopup";
import SearchInput from "@src/components/common/Inputs/SearchInput";
import ShowGridFilter from "@src/components/common/Switch/ShowGridFilter";
import { RootState } from "@src/redux/reducers";
import { handleRemoveFilter, handleShowFilterDialog } from "@src/redux/reducers/slice/orderHistory";
import { OrderGridColumns } from "./OrderHIstoryGrid";

interface IOrderHeaderProps {
  handleSearchKeyword: (e: InputChangeEvent) => void;
  handleSearch: () => void;
  handleExport: () => void;
  searchKeyword?: string;
}

const OrderHeader = (props: IOrderHeaderProps) => {
  const { handleSearchKeyword, handleSearch, handleExport, searchKeyword } = props;

  const dispatch = useDispatch();

  const filterTags = useSelector((state: RootState) => state.orderHistoryAction.filterTags);

  const handleFilterClick = () => {
    dispatch(handleShowFilterDialog());
  };

  const handleRemoveTag = (tagName: string) => {
    dispatch(handleRemoveFilter(tagName));
  };

  const columnsPopup = useRef<Button>(null);

  const [columnsPopupShowHide, setColumnsPopupShowHide] = useState(false);

  const showColumnsPopup = () => {
    setColumnsPopupShowHide(!columnsPopupShowHide);
  };

  return (
    <div className="order-header">
      <div className="row align-items-end">
        <div className="col-xxl-6 col-xl-6 col-lg-5 col-md-5">
          <SearchInput
            handleSearch={handleSearch}
            handleSearchChange={handleSearchKeyword}
            searchKeyword={searchKeyword}
          />
        </div>
        <div className="col">
          <div className="d-flex align-items-center justify-content-end">
            <Button
              imageUrl={col}
              title="Columns"
              className="me-2"
              onClick={showColumnsPopup}
              ref={columnsPopup}
              color="transparent"
            >
              Columns
            </Button>
            <ShowGridFilter />
            {/* <Button themeColor="primary" icon="filter" className="ms-2" onClick={handleFilterClick}>
              Filter
            </Button> */}
            <CustomPopup
              key="column-filters"
              anchor={columnsPopup.current?.element}
              popupAlign={{ horizontal: "left", vertical: "top" }}
              show={columnsPopupShowHide}
              setShow={setColumnsPopupShowHide}
              popupClass={"popup-content columns-popup"}
            >
              <ul>
                {OrderGridColumns.map((column, index) => {
                  return (
                    <li key={"column" + index}>
                      <Checkbox
                        defaultChecked={column.show}
                        label={column.title}
                        checked={column.show}
                        onChange={(e) => {
                          console.log("hello", e);
                        }}
                      />
                    </li>
                  );
                })}
              </ul>
            </CustomPopup>
            <Button themeColor="primary" icon="download" className="ms-2" onClick={handleExport}>
              Export
            </Button>
          </div>
        </div>
      </div>
      <Reveal transitionEnterDuration={150} transitionExitDuration={150}>
        {filterTags && filterTags.length > 0 && (
          <div className="d-flex gap-2 align-items-center">
            <div>Filters:</div>
            <div className="d-flex flex-wrap gap-3">
              {filterTags.map((tag) => {
                return (
                  <div key={tag.name} className="tag">
                    {tag.tagValue}
                    <span
                      onClick={() => handleRemoveTag(tag.name)}
                      className="k-icon k-font-icon k-i-clear-circle ms-2 cursor-pointer"
                    ></span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </Reveal>
    </div>
  );
};

export default memo(OrderHeader);
