import { InputChangeEvent } from "@progress/kendo-react-inputs";
import { useCallback, useState } from "react";
import Filters from "./Components/Filters";
import OrderHeader from "./Components/OrderHeader";
import OrderHistoryGrid from "./Components/OrderHIstoryGrid";

const OrderHistory = () => {
  const [searchKeyword, setSearchKeyword] = useState("");

  const handleSearchKeyword = useCallback((e: InputChangeEvent) => {
    setSearchKeyword(e.value);
  }, []);

  const handleSearch = useCallback(() => {}, []);

  const handleExport = useCallback(() => {}, []);

  return (
    <div className="d-flex flex-column gap-3 overflow-auto">
      <OrderHeader
        searchKeyword={searchKeyword}
        handleExport={handleExport}
        handleSearchKeyword={handleSearchKeyword}
        handleSearch={handleSearch}
      />
      <OrderHistoryGrid />
      <Filters />
    </div>
  );
};

export default OrderHistory;
