import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import LoadingPanel from "@src/components/common/LoadingPanel";
import { config } from "@src/config";
import { loggedInUser } from "@src/helpers/loggedInUser";
import { useAuthenticateMutation } from "@src/redux/reducers/api/authApi";
import Logo from "../../../assets/logo/LogoWhite.svg";

let timer: NodeJS.Timeout;

interface IVerificationMessageProps {
  initial: string;
  verified: string;
  afterVerification: string;
}
const verificationMessage: IVerificationMessageProps = {
  initial: "Logging In...",
  verified: "Logged In 🥳",
  afterVerification: "Redirecting to Home Screen...",
};

interface EmailConfirmationPageErrorMessagesProps {
  emailConfirmationError: string;
}

const EmailConfirmationPageErrorMessages = (props: EmailConfirmationPageErrorMessagesProps) => {
  const { emailConfirmationError } = props;

  let message = "Whoops, something isn't working right.";

  if (emailConfirmationError.toUpperCase() === "INVALID TOKEN") {
    message = "This email address has already been validated.";
  } else {
    message = "Whoops, something isn't working right.";
  }

  return (
    <span>
      {message}
      <span>
        &nbsp;Please&nbsp;
        <a target="_blank" rel="noreferrer" href={config.ssoUrl}>
          Log In
        </a>
        <span>&nbsp;or visit our&nbsp;</span>
        <a target="_blank" rel="noreferrer" href={"https://help.syncware.com/"}>
          Help Center
        </a>
        .
      </span>
    </span>
  );
};

interface IAuthenticatingUserProps {
  token: string;
}

const AuthenticatingUser = ({ token }: IAuthenticatingUserProps) => {
  const [isValidToken, setIsValidToken] = useState(true);
  const [loadingText, setLoadingText] = useState<string>(verificationMessage.initial);

  const isUserInLocalStorage = loggedInUser.getUser();
  const [AuthenticateUser, { isSuccess, isError, data }] = useAuthenticateMutation();

  const setLoadingStateAccordingToStatus = (
    status: "initial" | "verified" | "afterVerification",
    callback?: () => void,
  ) => {
    if (timer) {
      clearTimeout(timer);
    }
    timer = setTimeout(() => {
      setLoadingText(verificationMessage[status]);
      if (callback) {
        callback();
      }
    }, 2000);
  };

  useEffect(() => {
    const callback = (isValidToken: boolean) => {
      setIsValidToken(isValidToken);
      if (isValidToken) {
        const callbackAfterVerified = () => {
          // const callBackForRedirectToLogin = () => {
          //   window.location.href = window.location.origin + "/order-history";
          // };
          setLoadingStateAccordingToStatus("afterVerification");
        };
        setLoadingStateAccordingToStatus("verified", callbackAfterVerified);
      }
    };

    if (isSuccess) {
      callback(true);
    }

    if (isError) {
      callback(false);
    }

    const response = data;

    if (response) {
      loggedInUser.setUser(data);
    }
  }, [isSuccess, isError, data]);

  useEffect(() => {
    if (token && token.length > 0) {
      if (timer) {
        clearTimeout(timer);
      }

      timer = setTimeout(() => {
        if (isUserInLocalStorage) {
          return;
        }

        void AuthenticateUser(token);
      }, 2000);
    } else {
      setIsValidToken(false);
    }
  }, [token]);

  if (isUserInLocalStorage) {
    return <Navigate to="/order-history" replace={true} />;
  }

  return (
    <div className="app-container" style={{ background: "#F8F6F4" }}>
      <div className="app-login text-center">
        {isValidToken ? (
          <LoadingPanel loadingText={loadingText} />
        ) : (
          <h5 className="k-loading-mask">
            <div className="d-flex login-page-logo justify-content-center align-item-center mb-5">
              <img alt="Syncware" width={50} src={Logo} className="center login-logo-image" />
            </div>
            <EmailConfirmationPageErrorMessages emailConfirmationError={" "} />
          </h5>
        )}
      </div>
    </div>
  );
};

export default AuthenticatingUser;
