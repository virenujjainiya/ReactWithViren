import { Navigate } from "react-router-dom";
import useIsUserLoggedInSSO from "@src/hooks/useIsUserLoggedInSSO";
import AuthenticatingUser from "./AuthenticatingUser";

const AuthenticateUser = () => {
  const { token, isLoggedIn } = useIsUserLoggedInSSO();

  if (isLoggedIn && token) {
    return <AuthenticatingUser token={token} />;
  }

  return <Navigate to="/" />;
};

export default AuthenticateUser;
