const Retailer = () => {
  return <div>Retailer</div>;
};

export default Retailer;
