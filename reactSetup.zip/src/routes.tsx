import { lazy, Suspense } from "react";
import { NonIndexRouteObject } from "react-router-dom";
import LoadingPanel from "./components/common/LoadingPanel";
import OrderHistoryDetailPage from "./components/pages/Order History/DetailPage/OrderHistoryDetailPage";
import Vendor from "./components/pages/Vendor/Vendor";

const OrderHistory = lazy(() => import("./components/pages/Order History/OrderHistory"));
const DetailPageOfOrderHistory = lazy(
  () => import("./components/pages/Order History/DetailPage/DetailPageOfOrderHistory"),
);
const AuthWrapper = lazy(() => import("./components/pages/layout/AuthWrapper"));
const AppLayout = lazy(() => import("./components/pages/layout/AppLayout"));
const AuthenticateUser = lazy(() => import("./components/pages/Authenticate/AuthenticateUser"));

export interface IAuthorizedRoutes extends NonIndexRouteObject {
  headerName?: string;
  variable?: string;
  children?: IAuthorizedRoutes[];
}

export const authorizedRoutes: IAuthorizedRoutes[] = [
  {
    path: "order-history",
    element: <OrderHistory />,
    headerName: "Order History",
  },
  {
    path: "order-history/:id",
    element: <OrderHistoryDetailPage />,
    headerName: "Order History Details",
    variable: ":id",
  },
  {
    path: "vendor",
    element: <Vendor />,
  },
];

const routes = [
  {
    path: "/",
    element: (
      <Suspense
        fallback={
          <div className="app-container">
            <div className="app-login text-center">
              <LoadingPanel />
            </div>
          </div>
        }
      >
        <AuthWrapper>
          <AppLayout />
        </AuthWrapper>
      </Suspense>
    ),
    children: authorizedRoutes,
  },
  {
    path: "/authenticate",
    element: <AuthenticateUser />,
  },
];

export default routes;
