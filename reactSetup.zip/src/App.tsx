import { StrictMode } from "react";
import CacheBuster from "react-cache-buster";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import packageJson from "../package.json";
import LoadingPanel from "./components/common/LoadingPanel";
import routes from "./routes";

function App() {
  const router = createBrowserRouter(routes);

  const isProduction = import.meta.env.PROD;
  const version = packageJson.version;

  return (
    <StrictMode>
      <CacheBuster
        currentVersion={version}
        isEnabled={isProduction} //If false, the library is disabled.
        isVerboseMode={false} //If true, the library writes verbose logs to console.
        loadingComponent={<LoadingPanel />} //If not pass, nothing appears at the time of new version check.
        metaFileDirectory={"."} //If public assets are hosted somewhere other than root on your server.
      >
        <RouterProvider router={router} />
      </CacheBuster>
    </StrictMode>
  );
}

export default App;
