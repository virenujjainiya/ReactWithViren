interface IVendor {
  id: number;
  code: string;
  name: string;
  email: string;
  longName: string;
}

export default IVendor;
